<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        <link rel="stylesheet" href="css/style.css">
        <title>Tela inicial</title>
    </head>
    <body>
        <section>
        <div class="search-box">
            <input type="search-txt" id="pesquisaDM" type="text" name="" placeholder="Pesquise seu mercado" ">
            <a class="search-btn"></a>
            <i class="fas fa-search"></i>

        </div>  
        </section>      
        <sectiion class = "area-mercado">
        <div class = "mercado">
            <form>
                <h1>Procura fácil</h1>
                <a href="https://www.extra.com.br/"><button type="button">Extra</button></a>
                </br>
                <a href="https://www.assai.com.br/"><button type="button">Assaí</button></a>
            </form>
        </div>
        </sectiion>
    </body>
</html>