<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "procurafacil";

// Criar conexão
$conn = new mysqli($servername,
$username, $password, $dbname);
// Verificar a conexão
if ($conn->connect_error) {
die("Erro na Conexão: " . $conn->connect_error);
}

$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$senha = $_POST['senha'];


$sql = "INSERT INTO clientes (nome, cpf, email, senha) VALUES ('$nome', '$cpf', '$email', '$senha')";

if ($conn->query($sql) == TRUE) {
	echo "Novo Registro com sucesso</br>";
	echo "Você gravou o seguinte registro no banco:</br>";
	echo "O nome: $nome </br>";
	echo "O cpf: $cpf </br>";
	echo "O email: $email </br>";
	echo "O senha: $senha </br>";
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>