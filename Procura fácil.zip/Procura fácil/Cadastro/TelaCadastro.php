<!DOCTYPE HTML>
<html>
	<head>
	
        <link rel="stylesheet" href="css/style2.css">
		
		<?php
		// define as variaveis
		$nome = $cpf = $email = $senha = $confirm_senha = "";
		$erro_nome = $erro_senha = $confirm_password_err = $email_err="";
		
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$nome = ValorDigitado($_POST["nome"]);
			$cpf = ValorDigitado($_POST["cpf"]);
			$email = ValorDigitado($_POST["email"]);
			$senha = ValorDigitado($_POST["senha"]);
		}
		function ValorDigitado($valor) {
			$valor = trim($valor); //trim - Remover caracteres de ambos os lados de um texto
			$valor = stripslashes($valor);//stripslashes - remove as barras invertidas adicionadas pela função
			$valor = htmlspecialchars($valor); //htmlspecialchars - converte alguns caracteres predefinidos em entidades HTML, exemplo: > (Maior que em -->) &gt;
			return $valor;
		}
		?>
	</head>
	<body>
		<div class="cadastro">
			<form method="POST" action="TesteSla.php">
            <h5>Procura fácil</h5></br>
				
				<span class="mensagem_erro"><?php if (!empty($erro_nome)){echo "Erro: ". $erro_nome;}?>Nome:</span>
				<input type="text" placeholder="Nome" name="nome">
				<br>

				<span>CPF:</span>
            	<input type ="cpf" placeholder="CPF" name="cpf" id="cpf" maxlength="14"\pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" \ title="Digite um CPF no formato: xxx.xxx.xxx-xx">
				<br>

				<span class="mensagem_erro"><?php if (!empty($email_err)){echo "Erro: ". $email_err;}?>E-mail:</span>  
            	<input type="text" placeholder="Email" name = "email">
            	<br>

				<span class="mensagem_erro"><?php if (!empty($erro_senha)){echo "Erro: ". $erro_senha;}?>Senha:</span>  
            	<input type="password" placeholder="Senha" name = "senha">
				<br>

				<span class="mensagem_erro"><?php if (!empty($confirm_password_err)){echo "Erro: ". $confirm_password_err;}?>Confirmar Senha:</span>
				<input type="password" placeholder="Confirmar Senha" name="confirm_senha">
				</br>

				
				<input type="submit" name="submit" value="cadastrar" id="button">
			</form>
	</body>
</html>