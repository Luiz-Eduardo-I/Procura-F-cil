<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <meta name="viewport" content="width=device-width">
    <title>Tela de Login</title>

  </head>
  <body>
    <sectiion class = "area-login">
      <div class ="login">
        <!--<div>
          <img src="C:\xampp\htdocs\Procura fácil\login\images.jpg">
        </div>-->
        <form method= "POST">
          <input type="text" name="nome" placeholder="nome de usuario" autofocus>
          </br>
          <input type="password" name="senha" placeholder="sua senha">
          <footer>
          <a href="file:///D:/MVP/Tela%20Inicial/Tela%20inicial.html"><button>entrar</button:></a>
          </footer>
        </form>
        <p>ainda não tem uma conta?<a href="C:\xampp\htdocs\Procura fácil\Cadastro\TelaCadastro.php">criar conta</a></p>
      </div>
    </sectiion>
  </body>
</html>
<a></a>